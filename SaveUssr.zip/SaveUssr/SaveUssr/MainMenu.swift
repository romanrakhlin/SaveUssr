//
//  MainMenu.swift
//  SaveUssr
//
//  Created by Roma Rakhlin on 8/6/19.
//  Copyright © 2019 Roman Rakhlin. All rights reserved.
//

import SpriteKit

class MainMenu: SKScene {
    var starfield:SKEmitterNode!
    var newGameBtnNode:SKSpriteNode!
    override func didMove(to view: SKView) {
        starfield = (self.childNode(withName: "starfiled_anim") as! SKEmitterNode)
        starfield.advanceSimulationTime(10)
        newGameBtnNode = (self.childNode(withName: "newGameBtn") as! SKSpriteNode)
        newGameBtnNode.texture = SKTexture(imageNamed: "newGameBtn")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if let location = touch?.location(in: self) {
            let nodesArray = self.nodes(at: location)
            if nodesArray.first?.name == "newGameBtn" {
                let transition = SKTransition.flipVertical(withDuration: 0.5)
                let gameScene = GameScene(size: UIScreen.main.bounds.size)
                self.view?.presentScene(gameScene, transition: transition)
            }
        }
    }
}

