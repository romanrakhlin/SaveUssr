//
//  GameScene.swift
//  SaveUssr
//
//  Created by Roma Rakhlin on 8/6/19.
//  Copyright © 2019 Roman Rakhlin. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    var starfield:SKEmitterNode!
    var player:SKSpriteNode!
    var scoreLabel:SKLabelNode!
    var gameTimer:Timer!
    var aliens = ["alien"]
    let alienCategory:UInt32 = 0x1 << 1
    let playerCategory:UInt32 = 0x1 << 2
    let motionManager = CMMotionManager()
    var xAccelerate:CGFloat = 0
    var lives = 4
    var liveSprite:SKSpriteNode!
    var livesArray = [SKSpriteNode]()
    override func didMove(to view: SKView) {
        showLives()
        starfield = SKEmitterNode(fileNamed: "Starfield")
        starfield.position = CGPoint(x: 350, y: 1472)
        starfield.advanceSimulationTime(10)
        self.addChild(starfield)
        starfield.zPosition = -1
        player = SKSpriteNode(imageNamed: "shuttle")
        player.position = CGPoint(x: UIScreen.main.bounds.width / 2, y: 40)
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        player.physicsBody?.isDynamic = true
        player.physicsBody?.categoryBitMask = playerCategory
        player.physicsBody?.contactTestBitMask = alienCategory
        player.physicsBody?.collisionBitMask = 0
        player.setScale(0.9)
        self.addChild(player)
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        self.physicsWorld.contactDelegate = self
        let timeInterval = 1.1
        gameTimer = Timer.scheduledTimer(timeInterval: timeInterval, target: self, selector: #selector(addAlien), userInfo: nil, repeats: true)
        motionManager.accelerometerUpdateInterval = 0.2
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data: CMAccelerometerData?, error: Error?) in
            if let accelerometrData = data {
                let acceleration = accelerometrData.acceleration
                self.xAccelerate = CGFloat(acceleration.x) * 0.75 + self.xAccelerate * 0.25
            }
        }
    }
    
    func showLives() {
        for i in 1...lives {
            liveSprite = SKSpriteNode(imageNamed: "shuttle")
            liveSprite.position = CGPoint(x: UIScreen.main.bounds.width + 10 - liveSprite.size.width * CGFloat(i), y: UIScreen.main.bounds.height + -30 - liveSprite.size.height)
            liveSprite.zPosition = 1
            liveSprite.setScale(0.8)
            self.addChild(liveSprite)
            livesArray.append(liveSprite)
        }
    }
    
    override func didSimulatePhysics() {
        player.position.x += xAccelerate * 50
        if player.position.x < 0 {
            player.position = CGPoint(x: UIScreen.main.bounds.width - player.size.width, y: player.position.y)
        } else if player.position.x > UIScreen.main.bounds.width {
            player.position = CGPoint(x: 20, y: player.position.y)
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody:SKPhysicsBody
        var secondBody:SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            secondBody = contact.bodyA
            firstBody = contact.bodyB
        } else {
            secondBody = contact.bodyB
            firstBody = contact.bodyA
        }
        if (secondBody.categoryBitMask & alienCategory) != 0 && (firstBody.categoryBitMask & playerCategory) != 0 {
            playerDamage(playerNode: firstBody.node as! SKSpriteNode, alienNode: secondBody.node as! SKSpriteNode)
        }
    }
    
    func playerDamage(playerNode:SKSpriteNode, alienNode:SKSpriteNode) {
        let explosion = SKEmitterNode(fileNamed: "Vzriv")
        explosion?.position = alienNode.position
        self.addChild(explosion!)
        self.run(SKAction.playSoundFileNamed("vzriv.mp3", waitForCompletion: false))
        alienNode.removeFromParent()
        self.run(SKAction.wait(forDuration: 2)) {
            explosion?.removeFromParent()
        }
        livesArray.last?.removeFromParent()
        livesArray.removeLast()
        if livesArray.count == 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(70), execute: {
                self.player.removeFromParent()
                let scene = MainMenu(fileNamed: "MainMenu")!
                scene.scaleMode = SKSceneScaleMode.aspectFill
                self.view!.presentScene(scene)
            })
        }
    }
    
    @objc func addAlien() {
        aliens = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: aliens) as! [String]
        let alien = SKSpriteNode(imageNamed: aliens[0])
        let randomPos = GKRandomDistribution(lowestValue: 20, highestValue: Int(UIScreen.main.bounds.size.width - 20))
        let pos = CGFloat(randomPos.nextInt())
        alien.position = CGPoint(x: pos, y: UIScreen.main.bounds.size.height + alien.size.height)
        alien.physicsBody = SKPhysicsBody(rectangleOf: alien.size)
        alien.physicsBody?.isDynamic = true
        alien.physicsBody?.categoryBitMask = alienCategory
        alien.physicsBody?.collisionBitMask = 0
        alien.setScale(0.7)
        self.addChild(alien)
        let animDuration:TimeInterval = 6
        var actions = [SKAction]()
        actions.append(SKAction.move(to: CGPoint(x: pos, y: 0 - alien.size.height), duration: animDuration))
        actions.append(SKAction.removeFromParent())
        alien.run(SKAction.sequence(actions))
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let position = touch.location(in: self)
            player.position = CGPoint(x: position.x, y: position.y)
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
    }
}
